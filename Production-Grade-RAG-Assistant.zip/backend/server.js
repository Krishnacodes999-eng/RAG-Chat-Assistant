require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const OpenAI = require("openai");

const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

let vectorStore = [];
let sessions = {};

function cosineSimilarity(a, b) {
  const dot = a.reduce((sum, val, i) => sum + val * b[i], 0);
  const normA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
  const normB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));
  return dot / (normA * normB);
}

async function generateEmbedding(text) {
  const response = await client.embeddings.create({
    model: "text-embedding-3-small",
    input: text
  });
  return response.data[0].embedding;
}

async function initialize() {
  const docs = JSON.parse(fs.readFileSync("./docs.json"));
  for (const doc of docs) {
    const embedding = await generateEmbedding(doc.content);
    vectorStore.push({ content: doc.content, embedding });
  }
  console.log("Documents embedded successfully");
}

app.post("/api/chat", async (req, res) => {
  try {
    const { sessionId, message } = req.body;
    if (!sessionId || !message) {
      return res.status(400).json({ error: "Invalid request" });
    }

    const queryEmbedding = await generateEmbedding(message);

    const scored = vectorStore.map(chunk => ({
      ...chunk,
      score: cosineSimilarity(queryEmbedding, chunk.embedding)
    }));

    scored.sort((a, b) => b.score - a.score);
    const topChunks = scored.slice(0, 3);

    if (topChunks[0].score < 0.75) {
      return res.json({
        reply: "I do not have enough information.",
        retrievedChunks: 0
      });
    }

    const context = topChunks.map(c => c.content).join("\n");
    if (!sessions[sessionId]) sessions[sessionId] = [];

    const history = sessions[sessionId]
      .map(h => `${h.role}: ${h.content}`)
      .join("\n");

    const prompt = `
Answer ONLY from the context below.
If answer is not present, say:
"I do not have enough information."

Context:
${context}

Conversation History:
${history}

User Question:
${message}
`;

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.2,
      messages: [{ role: "user", content: prompt }]
    });

    const reply = response.choices[0].message.content;

    sessions[sessionId].push({ role: "user", content: message });
    sessions[sessionId].push({ role: "assistant", content: reply });

    if (sessions[sessionId].length > 10) {
      sessions[sessionId] = sessions[sessionId].slice(-10);
    }

    res.json({
      reply,
      retrievedChunks: topChunks.length
    });

  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

initialize().then(() => {
  app.listen(5000, () => console.log("Server running on port 5000"));
});
