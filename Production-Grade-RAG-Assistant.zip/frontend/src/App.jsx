import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sessionId = localStorage.getItem("sessionId") || uuidv4();
  localStorage.setItem("sessionId", sessionId);

  const handleSend = async () => {
    if (!input) return;

    const userMessage = { role: "user", content: input };
    setMessages([...messages, userMessage]);

    const response = await fetch("http://localhost:5000/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, message: input })
    });

    const data = await response.json();

    setMessages(prev => [
      ...prev,
      { role: "assistant", content: data.reply }
    ]);

    setInput("");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Production RAG Assistant</h2>
      <div>
        {messages.map((msg, i) => (
          <p key={i}><b>{msg.role}:</b> {msg.content}</p>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}

export default App;
